INFO: https://github.com/Devocub/TabletDriver
FAQ: https://github.com/hawku/TabletDriver/wiki/FAQ
Report issues: https://github.com/hawku/TabletDriver/issues